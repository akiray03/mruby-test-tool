class Rb3
  Const = 'Rb3::Const'
end
rb3 = 1

if $0 == __FILE__
  $rb3_exec = true
else
  $rb3_not_exec = true
end
