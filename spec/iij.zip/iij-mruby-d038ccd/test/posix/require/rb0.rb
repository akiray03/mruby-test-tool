class Rb0
  Const = 'Rb0::Const'
end
rb0 = 1

$rb0_filename = __FILE__
