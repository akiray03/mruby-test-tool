class Mrb1
  Const = 'Mrb1::Const'
end
mrb1 = 1
