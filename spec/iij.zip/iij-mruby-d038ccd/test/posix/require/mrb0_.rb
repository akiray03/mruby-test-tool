class Mrb0
  Const = 'Mrb0::Const'
end
mrb0 = 1

$mrb0_filename = __FILE__
