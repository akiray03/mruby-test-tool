$rb6c = "rb6c"
require "rb6_notfound"
require "rb6a"
