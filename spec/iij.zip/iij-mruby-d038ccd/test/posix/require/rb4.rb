$rb4 = true
raise "test error"
