$rb5 = true
class RequireTestError < StandardError
end
raise RequireTestError, "msg"
