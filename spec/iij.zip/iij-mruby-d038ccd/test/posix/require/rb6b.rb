$rb6b = "rb6b"
require "rb6a"
