$rb6a = "rb6a"
require "rb6b"
