class Rb2
  Const = 'Rb2::Const'
end
rb2 = 1

require "dir/rb1"

