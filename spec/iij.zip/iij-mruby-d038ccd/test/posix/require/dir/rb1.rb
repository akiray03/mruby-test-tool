class Rb1
  Const = 'Rb1::Const'
end
rb1 = 1
